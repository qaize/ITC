package ListEnum;

public enum JenisKelamin {
    LAKI_LAKI,
    PEREMPUAN
}
