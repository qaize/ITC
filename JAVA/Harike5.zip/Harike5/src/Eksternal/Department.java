package Eksternal;

public class Department {
    private String nama;
    private String description;

    public void setNama(String nama){this.nama=nama;}
    public String getNama(){return this.nama;}

    public void setDescription(String desc){this.description=desc;}
    public String getDescription(){return this.description;}

}
